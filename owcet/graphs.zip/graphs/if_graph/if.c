int main () {
    int a = 1;
    int b = 2;
    int c = 3;
    int d = 4;
    if (a == 1) {
        b = 2;
        if (c == 3) {
            d = 4;
        }
    }
    return 0;
}